import argparse
import base64 as b64
import json
import logging
import random
from datetime import datetime
from typing import Dict
from zoneinfo import ZoneInfo

from pydeequ.analyzers import AnalysisRunner, AnalyzerContext, Size, Completeness, Uniqueness, Distinctness, ApproxCountDistinct, Compliance, Histogram, Entropy
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, col, to_date, to_timestamp
from pyspark.sql.types import StructType, StructField, StringType

from mmix.common.utils import validation_results_store, generate_user_session_logs


def decode_secret(b64_json: str) -> Dict:
    return json.loads(b64.b64decode(b64_json).decode("utf-8"))


def get_args(parser):
    parser.add_argument('--dag_id', type=str, default="dataplatform_dashboard_international_risk_daily", help="Dag ID for tracking")
    parser.add_argument('--run_id', type=str, default="", help="Run ID for tracking")
    parser.add_argument("--secret", type=str, required=False, help="base64 encoded json string")
    parser.add_argument('--environment', type=str, default="prod", help="Environment for the job (e.g., dev, stg, prod)")
    parser.add_argument('--logical_datetime', type=str, default=datetime.now(tz=ZoneInfo("UTC")).strftime("%Y-%m-%d %H:%M:%S"))
    logging.info(f"Arguments: {parser.parse_args()}")
    return parser.parse_args()


def get_schema():
    return StructType([
        StructField("user_id", StringType(), nullable=False),
        StructField("session_id", StringType(), nullable=False),
        StructField("install", StructType([
            StructField("id", StringType(), nullable=False),
            StructField("country", StringType(), nullable=False),
            StructField("language", StringType(), nullable=False),
            StructField("installed_at", StringType(), nullable=False), ]), nullable=False),
        StructField("device", StructType([
            StructField("os", StringType(), nullable=False),
            StructField("os_version", StringType(), nullable=False),
            StructField("type", StringType(), nullable=False),
            StructField("model", StringType(), nullable=False), ]), nullable=False),
        StructField("app", StructType([
            StructField("version", StringType(), nullable=False), ]), nullable=False),
        StructField("network", StructType([
            StructField("ip", StringType(), nullable=False), StructField("carrier", StringType(), nullable=True)
        ]), nullable=False),
        StructField("event", StructType([
            StructField("timestamp", StringType(), nullable=False),
            StructField("type", StringType(), nullable=False),
            StructField("menu", StringType(), nullable=False),
            StructField("action", StringType(), nullable=False),
            StructField("content", StructType([
                StructField("id", StringType(), nullable=True),
                StructField("title", StringType(), nullable=True), ]), nullable=True),
            StructField("referrer", StringType(), nullable=True), ]), nullable=False),
    ])


def flatten_app_log(df):
    return (
        df.select(
            "user_id",
            "session_id",
            col("install.id").alias("install_id"),
            col("install.country").alias("install_country"),
            col("install.language").alias("install_language"),
            to_date("install.installed_at").alias("install_installed_at"),
            col("device.os").alias("device_os"),
            col("device.os_version").alias("device_os_version"),
            col("device.type").alias("device_type"),
            col("device.model").alias("device_model"),
            col("app.version").alias("app_version"),
            col("network.ip").alias("network_ip"),
            col("network.carrier").alias("network_carrier"),
            to_timestamp("event.timestamp").alias("event_ts"),
            col("event.type").alias("event_type"),
            col("event.menu").alias("event_menu"),
            col("event.action").alias("event_action"),
            col("event.content.id").alias("content_id"),
            col("event.content.title").alias("content_title"),
            col("event.referrer").alias("event_referrer"),
        )
    )


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format='[%(asctime)s] %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)
    logging.info("Example Deequ User App Log Data Quality")
    _args = get_args(argparse.ArgumentParser())
    _dag_id = _args.dag_id
    _run_id = _args.run_id
    _secret = decode_secret(_args.secret)
    _environment = _args.environment
    _logical_datetime = _args.logical_datetime

    with (SparkSession.builder.appName("dataplatform_dashboard_international_risk_daily").getOrCreate() as _spark):
        logger.info(f"Spark session started.")
        logger.info(f"Dag ID: {_dag_id}, Run ID: {_run_id}, Logical Datatime: {_logical_datetime}, Environment: {_environment}, Secret: {_secret}")
        raw_dataframe = _spark.createDataFrame(generate_user_session_logs(random.randint(100, 15000)), schema=get_schema())
        dataframe = raw_dataframe.transform(flatten_app_log)
        analysis_result = AnalysisRunner(_spark) \
            .onData(dataframe) \
            .addAnalyzer(Size()) \
            .addAnalyzer(Completeness("user_id")) \
            .addAnalyzer(Completeness("session_id")) \
            .addAnalyzer(Completeness("install_id")) \
            .addAnalyzer(Completeness("install_country")) \
            .addAnalyzer(Completeness("install_language")) \
            .addAnalyzer(Completeness("device_os")) \
            .addAnalyzer(Completeness("app_version")) \
            .addAnalyzer(Completeness("event_ts")) \
            .addAnalyzer(Completeness("event_type")) \
            .addAnalyzer(Completeness("event_action")) \
            .addAnalyzer(Uniqueness(["session_id"])) \
            .addAnalyzer(Distinctness("session_id")) \
            .addAnalyzer(ApproxCountDistinct("user_id")) \
            .addAnalyzer(Uniqueness(["session_id", "event_ts"])) \
            .addAnalyzer(Histogram("install_country")) \
            .addAnalyzer(Histogram("event_type")) \
            .addAnalyzer(Histogram("event_menu")) \
            .addAnalyzer(Entropy("event_type")) \
            .addAnalyzer(Compliance("valid_ipv4", r"network_ip RLIKE '^(\\d{1,3}\\.){3}\\d{1,3}$'")) \
            .addAnalyzer(Compliance("valid_semver", r"app_version RLIKE '^\\d+\\.\\d+\\.\\d+$'")) \
            .addAnalyzer(Compliance("event_after_install", "event_ts IS NOT NULL AND install_installed_at IS NOT NULL AND event_ts >= install_installed_at")) \
            .run()

        analyzer_context = AnalyzerContext \
            .successMetricsAsDataFrame(_spark, analysis_result) \
            .withColumn("run_name", lit(_args.dag_id)) \
            .withColumn("run_id", lit(_args.run_id)) \
            .withColumn("logical_datetime", to_timestamp(lit(_logical_datetime), "yyyy-MM-dd HH:mm:ss"))
        analyzer_context.show()
        validation_results_store(analyzer_context, _secret, _environment)
